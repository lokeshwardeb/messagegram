<?php
require __DIR__ . '/../views/pages/views.index.php';


?>