<?php
echo 'this is the error page';
?>