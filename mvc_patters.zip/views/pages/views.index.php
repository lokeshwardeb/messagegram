<?php
echo 'welcome to the view index';

?>